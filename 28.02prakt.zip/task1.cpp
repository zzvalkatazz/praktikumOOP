#include<iostream>
const int MAX_CAPACITY = 20;
class Waffles {
	private:
	char manifacture[MAX_CAPACITY];
	double weight;
	double endPrice;
};
class Shop {
private:
	Waffles waffle;
	int numOfWaffles;
	double profits;
	double consumtion;
};