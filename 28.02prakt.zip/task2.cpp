#include<iostream>
#include<cmath>
class Triangle
{ 
private:
	double a;
	double b;
	double c;
	double sideHeight;
public:
	bool isRectangular()
	{
		return (a * a) + (b * b) == (c * c);
	}
	bool hasTwoEqual()
	{
		return a == b || b == c || c == a;
	}
	int sOfTriangle()
	{
		int p = (a + b + c) / 2;
		return sqrt(p * (p - a) * (p - b) * (p - c));
	}
	int pOfTriangle()
	{
		return a + b + c;
	}
	
	void inputTriangle()
	{
		std::cin >> a >> b >> c;
	}
	void inputSideHeight()
	{
		
		std::cin >> sideHeight;
	}
	int findHeight()
	{
		if (sideHeight == a)
		{
			return sOfTriangle() / a;
		}
		else if (sideHeight == b)
		{
			return sOfTriangle() / b;
		}
		else if (sideHeight == c)
		{
			return sOfTriangle() / c;
		}
		else
		{
			return 0;
		}
	}
	int findR()
	{
		return (a * b * c) / 4 * sOfTriangle();
	}
};
int main()
{
	Triangle triangle;
	triangle.inputTriangle();
	std::cout << "add side for height:";
	triangle.inputSideHeight();
	std::cout << triangle.isRectangular() << std::endl;
	std::cout << triangle.hasTwoEqual() << std::endl;
	std::cout << triangle.sOfTriangle() << std::endl;
	std::cout << triangle.pOfTriangle() << std::endl;
	std::cout << triangle.findHeight() << std::endl;
	std::cout << triangle.findR() << std::endl;
}
